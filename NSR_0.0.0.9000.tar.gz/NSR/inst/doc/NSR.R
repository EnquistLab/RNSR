## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- eval=FALSE--------------------------------------------------------------
#  
#  library(devtools)
#  install_github("EnquistLab/RNSR/NSR")
#  
#  

## -----------------------------------------------------------------------------
library(NSR)
NSR_super_simple(species = "Acer rubrum",
                 country =  "Canada", 
                 state_province = "Ontario")



## -----------------------------------------------------------------------------

head(NSR_template())


## -----------------------------------------------------------------------------

#First, pull the example data that are included with the package
data("nsr_testfile")
head(nsr_testfile)

example_results <- NSR(nsr_testfile)

head(example_results)


## -----------------------------------------------------------------------------

sources <- NSR_metadata()

checklist_political_divisions <- NSR_political_divisions()

#To only return political division information for a given country, specify that county (or countries) in the field

US_checklists <- NSR_political_divisions(country = "United States")



