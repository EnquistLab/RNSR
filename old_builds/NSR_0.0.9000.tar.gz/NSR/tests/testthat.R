library(testthat)
library(NSR)


test_check("NSR")
